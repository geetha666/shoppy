import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
name: any;
password: any;

  constructor(public router: Router) { }

  ngOnInit() {
  }

loginpage() {
  console.log("names", this.name)
  console.log("password", this.password)
  if(this.name=="" || this.name==undefined){
    alert("please enter user name")
  }
 
  else if(this.password=="" || this.password==undefined){
  alert("please enter password")
   }
 else if(this.name=="geeta" && this.password==1234)
 {
  this.router.navigate(['/dashboard'])
 }
 else{
  alert("logins incorrects")
 }


}




}
